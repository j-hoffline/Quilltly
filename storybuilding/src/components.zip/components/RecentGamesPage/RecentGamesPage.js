import React from 'react';
import { auth, database } from '../firebase';
import './dashboard-game-card.css';

class RecentGamesPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            error: "",
            profile: 0
        }
    }

    componentDidMount() {
        if (auth.currentUser) {
            database.ref('/users/' + auth.currentUser.uid).once('value').then((snapshot) => {
                let results = snapshot.val()
                if (!results) {
                //Error fetching recent games
                this.setState({...this.state, error: "There was an error fetching your profile."});
                return;
                } else {
                //Update state to hold user profile
                this.setState({...this.state, profile: results});
                }
            });
        }
    }

    render() {
        console.log(this.state);
        return(
            <div>
                <div class="game-card">
                    <h1 class="title">The Murder of Mr. Tibbles</h1>
                    <p class="preview">
                        It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout....
                    </p>
                    <div class="story-details">
                        <div class="story-setting">Public: Yes</div>
                        <div class="story-setting">Open: Yes</div>
                        <div class="story-setting">Word Count: 236</div>
                    </div>
                    </div>

                    <div class="game-card">
                    <h1 class="title">The Public Trial of Priscilla</h1>
                    <p class="preview">
                        It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout....
                    </p>
                    <div class="story-details">
                        <div class="story-setting">Length: 1</div>
                        <div class="story-setting">Open: Yes</div>
                        <div class="story-setting">Word Count: 236</div>
                    </div>                
                </div>
            </div>
        );
    }
}

export default RecentGamesPage;