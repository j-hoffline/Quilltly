import React from 'react';
import './create-new-game-page.css';
import {Dropdown, DropdownButton, Form, Button, ToggleButton} from 'react-bootstrap';


const randomString = require('randomstring');

class CreateNewGamePage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            storyIntro: "",
            gameCode: "",
            gamePublic: false
        }

        this.createGame = this.createGame.bind(this);
    }

    createGame() {

    }

    componentDidMount() {
        let generatedCode = randomString.generate({
            length: 12,
            charset: 'alphabetic'
        });
        this.setState({...this.state, gameCode: generatedCode});
    }

    render() {
        return(
            <div className="create-game-card">
                <Form onSubmit={this.createGame}>
                    <Form.Group id="storyIntro">
                        <Form.Control type="text" placeholder="How do you want to start your story..."
                            onChange={(event) => this.setState({...this.state, storyIntro: event.target.value})} required />
                    </Form.Group>
                    <Form.Group id="radioButtons">
                        <ToggleButton checked={this.state.gamePublic} type="checkbox"
                            onClick={() => this.setState({...this.state, gamePublic: !this.state.gamePublic})}>
                            Public
                        </ToggleButton>
                        <Form.Label>Max Contribution Length: </Form.Label>
                        <select>
                        <option value="one-word" selected>One Word</option> <br />
                        <option value="one-sentence" onClick={() => (console.log("one-sentence selected"))}>One Sentence</option> <br />
                        <option value="one-paragraph">One Paragraph</option> <br />
                        <option value="tweet-length">Tweet Length</option> <br />
                    </select>

                    <Form.Label>Game Code: <span>{this.state.gameCode}</span></Form.Label>
                    </Form.Group>
                </Form>
            </div>
        );
    }
}

export default CreateNewGamePage;

